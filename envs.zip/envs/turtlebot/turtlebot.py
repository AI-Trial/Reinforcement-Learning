#!/usr/bin/python
# -*- coding: utf-8 -*

# TODO observation spaceにホイールの回転速度を追加

import os
import sys
import traceback
import time
import numpy as np
import gym
from gym import spaces
import rospy
import tf
from geometry_msgs.msg import Twist

OBS = ['rob_x','rob_y','rob_rz','box_x','box_y','box_rz']

class TurtlebotEnv(gym.Env):
    def __init__(self):
        print 'Create a new environment'
        # init ROS node
        rospy.init_node('gym_turtlebot', anonymous=True)
        self.vel_commander = rospy.Publisher('/mobile_base/commands/velocity', Twist, queue_size=5)
        self.tf_listener = tf.TransformListener()
        # define observation space
        # rob_x[m], rob_y[m], rob_a[rad], box_x[m], box_y[m], box_a[rad])
        self.obs_low = np.array([-1.,-1.,-np.pi()]*2)
        self.obs_high = np.array([1., 1., np.pi()]*2)
        self.observation_space = spaces.Box(self.obs_low, self.obs_high)
        # define action space
        # vel, ang_vel
        self.act_low = np.array([-1.,-1.])
        self.act_high = np.array([1., 1.])
        self.action_space = spaces.Box(self.act_low, self.act_high)
        # reward = exp(sqrt(box_x^2 + box_y^2))
        self.reward_range = [0,1]
        # velocity command related value
        self.vel_cmd = Twist()
        self.max_vel = 0.1
        self.max_ang_vel = np.pi/6.
        # 制御周波数
        self.rate = rospy.Rate(4.)

    def init_value(self):
        self.time = np.empty(0)
        self.rob_pos = np.empty((0,3))
        self.box_pos = np.empty((0,3))
        self.vel = 0
        self.ang_vel = 0
        self.tf_too_late = False
        self.t0 = rospy.Time.now().to_sec()

    def reset(self):
        print 'Reset the environment'
        self.init_value()
        self.print_title(['time','rob_x','rob_y','rob_a','box_x','box_y','box_a','vel','ang_v'], 8)
        return self.get_obs()

    def print_title(self, title_list, digits):
        title = '|'
        for s in title_list:
            title = '{}{}|'.format(title, s.center(digits, ' '))
        print title

    def step(self, action):
        while not rospy.is_shutdown():
            try:
                # calculate velocity from action
                self.vel = action[0] * self.max_vel
                # calculate angular velocity from action
                self.ang_vel = action[1] * self.max_ang_vel
                # publish command
                self.vel_cmd.linear.x = self.vel
                self.vel_cmd.angular.z = self.ang_vel
                self.vel_commander.publish(vel_cmd)
                self.rate.sleep()
            except rospy.ROSInterruptException:
                print 'Keyboard Interruption'
                os._exit(0)
            except:
                traceback.print_exc()
                os._exit(0)
            else:
                obs = self.get_obs()
                reward = self.calc_reward()
                done = self.is_done()
                info = {}
                self.update_log()
                return obs, reward, done, info

    def get_obs(self):
        self.rob_pos = self.get_tf('/ar_marker_5', '/ar_marker_1')
        self.box_pos = self.get_tf('/ar_marker_5', '/ar_marker_2')
        return np.hstack((self.rob_pos, self.box_pos))

    def get_tf(self, origin, target):
        common = self.tf_listener.getLatestCommonTime(origin, target)
        (trans, rot) = self.tf_listener.lookupTransform(origin, target, common)
        pos = np.hstack((trans, rot))
        tf_delay = (rospy.Time.now() - common).to_sec()
        # TF が0.1秒以上遅れた場合
        if tf_delay > 0.1:
            self.tf_too_late = True
        return pos

    def calc_reward(self):
        x, y = self.box_pos[0], self.box_pos[1]
        error = np.sqrt(x**2 + y**2)
        reward = np.exp(error)
        return reward

    def is_done(self, obs):
        done = False
        # ワークスペース判定
        for i in range(len(obs)):
            if not self.obs_low[i] < obs[i] < self.obs_high[i]:
                print '\n{} = {} is out of range'.format(OBS[i], obs[i])
                done = True
        # TF の取得時間遅延判定
        if self.tf_too_late:
            print '\nTF is too late: {} [ms]'.format(tf_delay)
            done = True
        return done

    def update_log(self):
        time = self.time - self.t0
        log = np.hstack((time, obs))
        self.write_log(log)

    def write_log(self, log):
        log = '|'
        for data in log:
            log = '{}{: 8.3f}|'.format(log, data)
        sys.stdout.write('\r{}'.format(log))
        sys.stdout.flush()

if __name__ == '__main__':
    def policy(obs):
        action = np.array([0.5,0.])
        if obs[3] - obs[0] > 0:
            action[1] = -0.5
        elif obs[3] - obs[0] < 0:
            action[1] = +0.5
        else:
            action[1] = 0
        return action

    env = gym.make('Turtlebot-v0')
    obs = env.reset()
    done = False
    t = 0
    while not done:
        obs, reward, done, info = env.step(policy(obs))
        t+=1
        if t > 100:
            done = True
    print 'finish!'
